#!/bin/bash
# fetch_hc_data.sh - 从 HRBP 工作台抓取 HC 完整数据（v3）
# 包含：子部门HC、待入职（社招/校招/内转区分）、待离职、招聘统计
# 用法: ./fetch_hc_data.sh <workspace>
set -euo pipefail

WORKSPACE="${1:-/home/node/.openclaw/workspace}"
SSO_SKILL="/app/skills/data-fe-common-sso"

COOKIE=$(cd "$SSO_SKILL" && ./script/run-sso.sh "$WORKSPACE" 2>/dev/null) || {
  echo '{"error":"需要SSO登录"}' >&2; exit 1
}

BASE="https://hr.xiaohongshu.com/oasis/api/ehrworkbench"
H=(-s -H "Cookie: $COOKIE" -H "Content-Type: application/json")

post() { curl "${H[@]}" -X POST "$BASE$1" -d "$2"; }

# 三个顶层部门
DEPT_IDS='["5000273","5003008","5000785"]'

# 子部门 HC（含 children）
SUB_YIYE=$(post "/hrbp/pc/department/subDepartments" '{"departmentId":"5000273","needChildren":true}')
SUB_FUNC1=$(post "/hrbp/pc/department/subDepartments" '{"departmentId":"5003008","needChildren":true}')
SUB_FUNC2=$(post "/hrbp/pc/department/subDepartments" '{"departmentId":"5000785","needChildren":true}')

# 招聘统计
RECRUIT=$(post "/recruit/pc/allPositionProcessStatistic/query" "{\"departmentIdList\":$DEPT_IDS,\"pageNum\":1,\"pageSize\":200}")

# 待入职（社招+校招）
ENTRY_YIYE=$(post "/entry/pc/entryProcessDetail/query" '{"departmentIdList":["5000273"],"pageNum":1,"pageSize":100}')
ENTRY_FUNC=$(post "/entry/pc/entryProcessDetail/query" '{"departmentIdList":["5003008","5000785"],"pageNum":1,"pageSize":100}')

# 待离职
DIM_YIYE=$(post "/dimission/pc/dimissionProcessDetail/query" '{"departmentIdList":["5000273"],"pageNum":1,"pageSize":100}')
DIM_FUNC=$(post "/dimission/pc/dimissionProcessDetail/query" '{"departmentIdList":["5003008","5000785"],"pageNum":1,"pageSize":100}')

# 活水转入转出（区分内转）
TRANS_IN_YIYE=$(post  "/hrbp/pc/department/queryTransInInfo"  '{"departmentId":"5000273"}')
TRANS_OUT_YIYE=$(post "/hrbp/pc/department/queryTransOutInfo" '{"departmentId":"5000273"}')
TRANS_IN_F1=$(post    "/hrbp/pc/department/queryTransInInfo"  '{"departmentId":"5003008"}')
TRANS_OUT_F1=$(post   "/hrbp/pc/department/queryTransOutInfo" '{"departmentId":"5003008"}')
TRANS_IN_F2=$(post    "/hrbp/pc/department/queryTransInInfo"  '{"departmentId":"5000785"}')
TRANS_OUT_F2=$(post   "/hrbp/pc/department/queryTransOutInfo" '{"departmentId":"5000785"}')

jq -n \
  --argjson sub1 "$SUB_YIYE" \
  --argjson sub2 "$SUB_FUNC1" \
  --argjson sub3 "$SUB_FUNC2" \
  --argjson recruit "$RECRUIT" \
  --argjson entry1 "$ENTRY_YIYE" \
  --argjson entry2 "$ENTRY_FUNC" \
  --argjson dim1 "$DIM_YIYE" \
  --argjson dim2 "$DIM_FUNC" \
  --argjson ti1 "$TRANS_IN_YIYE" --argjson to1 "$TRANS_OUT_YIYE" \
  --argjson ti2 "$TRANS_IN_F1"   --argjson to2 "$TRANS_OUT_F1" \
  --argjson ti3 "$TRANS_IN_F2"   --argjson to3 "$TRANS_OUT_F2" \
  --arg fetchTime "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  '{
    fetchTime: $fetchTime,
    subDepts_5000273: $sub1.data,
    subDepts_5003008: $sub2.data,
    subDepts_5000785: $sub3.data,
    recruitStat: $recruit.data,
    entry_5000273: ($entry1.data.list // []),
    entry_func:    ($entry2.data.list // []),
    dimission_5000273: ($dim1.data.list // []),
    dimission_func:    ($dim2.data.list // []),
    transIn_5000273:  $ti1.data,
    transOut_5000273: $to1.data,
    transIn_5003008:  $ti2.data,
    transOut_5003008: $to2.data,
    transIn_5000785:  $ti3.data,
    transOut_5000785: $to3.data
  }'
