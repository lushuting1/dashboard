#!/bin/bash
# publish_to_github.sh - 将 HTML 文件推送到 GitHub Pages，返回访问 URL
#
# 用法: ./publish_to_github.sh <html_file> [repo] [path_in_repo]
#
# Token 读取顺序（任意一个有值即可）:
#   1. 环境变量 GITHUB_TOKEN
#   2. ~/.openclaw/workspace/.github_token 文件
#   3. skill 内置默认 token（skill 发布者共享）
#
# Repo 读取顺序:
#   1. 命令行参数 $2
#   2. 环境变量 GITHUB_PAGES_REPO
#   3. skill 内置默认 repo

set -euo pipefail

HTML_FILE="${1:-}"
REPO="${2:-}"
FILE_PATH="${3:-hc.html}"

# ── 内置默认配置（skill 发布者提供，其他用户无需自己配）──
DEFAULT_TOKEN="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"
DEFAULT_REPO="lushuting1/dashboard"
DEFAULT_FILE_PATH="hc.html"  # 不要覆盖 index.html（那是其他看板的入口）
# ─────────────────────────────────────────────────────────

if [[ -z "$HTML_FILE" || ! -f "$HTML_FILE" ]]; then
  echo "[ERROR] HTML 文件不存在: $HTML_FILE" >&2
  exit 1
fi

# 读 token（优先用用户自己的，没有才用内置）
TOKEN="${GITHUB_TOKEN:-}"
if [[ -z "$TOKEN" ]]; then
  TOKEN_FILE="${HOME}/.openclaw/workspace/.github_token"
  [[ -f "$TOKEN_FILE" ]] && TOKEN=$(cat "$TOKEN_FILE" | tr -d '[:space:]')
fi
[[ -z "$TOKEN" ]] && TOKEN="$DEFAULT_TOKEN"

# 读 repo
[[ -z "$REPO" ]] && REPO="${GITHUB_PAGES_REPO:-}"
[[ -z "$REPO" ]] && REPO="$DEFAULT_REPO"

# Base64 编码
CONTENT_B64=$(base64 -w 0 < "$HTML_FILE")

# 获取当前文件 SHA（更新时需要）
EXISTING_SHA=$(curl -s \
  -H "Authorization: token $TOKEN" \
  -H "User-Agent: hc-dashboard-skill" \
  "https://api.github.com/repos/${REPO}/contents/${FILE_PATH}" \
  | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('sha',''))" 2>/dev/null || echo "")

COMMIT_MSG="chore: update HC dashboard $(date '+%Y-%m-%d %H:%M')"

if [[ -n "$EXISTING_SHA" ]]; then
  PAYLOAD=$(python3 -c "
import json
print(json.dumps({'message':'${COMMIT_MSG}','content':'${CONTENT_B64}','sha':'${EXISTING_SHA}'}))
")
else
  PAYLOAD=$(python3 -c "
import json
print(json.dumps({'message':'${COMMIT_MSG}','content':'${CONTENT_B64}'}))
")
fi

RESPONSE=$(curl -s -X PUT \
  -H "Authorization: token $TOKEN" \
  -H "Content-Type: application/json" \
  -H "User-Agent: hc-dashboard-skill" \
  "https://api.github.com/repos/${REPO}/contents/${FILE_PATH}" \
  -d "$PAYLOAD")

# 解析返回 URL
python3 -c "
import json, sys
d = json.load(sys.stdin)
if 'content' in d:
    owner, reponame = '${REPO}'.split('/')
    path = '${FILE_PATH}'
    url = f'https://{owner}.github.io/{reponame}/' if path == 'index.html' else f'https://{owner}.github.io/{reponame}/{path}'
    print(url)
else:
    msg = d.get('message', str(d))
    print(f'[ERROR] {msg}', file=sys.stderr)
    sys.exit(1)
" <<< "$RESPONSE"
