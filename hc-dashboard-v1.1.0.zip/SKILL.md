---
name: hc-dashboard
description: 为小红书 HRBP 生成交互式 HC 管理看板，自动发布到 GitHub Pages。v1.1支持：气泡散点图、部门详情面板（子组柱状折线图+明细表）、流入流出人员明细（L1/L2高亮）、真实EHR数据接入、定时自动更新生成日期戳文件。触发词：生成HC看板、更新HC看板、HC dashboard、HC流动情况、发我HC看板链接。
---

# HC Dashboard Skill — v1.1

## 功能概览

为小红书 HRBP 生成交互式 HC 管理看板 HTML，自动发布到 GitHub Pages。

**当前看板地址**：https://lushuting1.github.io/dashboard/hc_v3.html

### v1.1 新增能力

| 能力 | 说明 |
|---|---|
| 🫧 气泡散点图 | X=满编率 / Y=在职规模 / 气泡大小=budget，SVG原生实现 |
| 🔍 部门详情面板 | 点击行业一部气泡/行名 → 弹出全屏面板，含25子组 |
| 📊 子组组合图 | 双柱(在职/目标)+折线(满编率)，纯SVG，hover tooltip |
| 📋 子组明细表 | 25行，满编率颜色标注，HC Gap超/缺/达标 badge |
| 👤 关键人 L1/L2 | 待入职/待离职分左右列，真实姓名+日期高亮 |
| 🔄 流入流出明细 | 各业务tab底部双列表，L1/L2行高亮显示 |
| ✅ 真实EHR数据 | 待入职7人/待离职4人，来自系统实时数据 |
| ⏰ 定时自动更新 | 每天9:00自动生成带日期戳文件，不覆盖专属看板 |

### 文件命名规则

| 用户类型 | 生成文件 | 说明 |
|---|---|---|
| 专属看板 | `hc_v3.html` | 瑾瑜的固定看板，永不覆盖 |
| 自动每日备份 | `hc_YYYYMMDD.html` | 如 `hc_20260402.html` |
| 其他HR使用 | `hc_{姓名}.html` | 如 `hc_tianxue.html` |

---

## 看板结构

```
📋 总览 tab（默认首页）
  ├─ 3个圆环图卡片（SVG circle + stroke-dasharray）
  ├─ 气泡散点图（满编率 vs 在职规模）
  └─ 🔄 关键人流动（L1/L2）：流入/流出各一卡

🛒 交易 tab
  ├─ 核心 KPI 卡（可点击→毛玻璃Modal）
  ├─ 满编率横向条形排行
  ├─ 部门明细表
  └─ 🔄 流入流出明细（双列）

🏢 商业 tab（同结构）
💰 财务 tab（同结构）

🔍 行业一部详情面板（点击触发）
  ├─ header：部门名/负责人/在职/规划/Gap/满编率
  ├─ 7个KPI卡
  ├─ 子组组合图：双柱+折线（25个子组）
  ├─ 关键人区域：待入职L1/L2 | L1/L2流出
  └─ 子组明细表：25行，带颜色/badge
```

---

## 真实系统数据（2026-04-02）

### 部门汇总

| 部门 | 在职 | Y26规划 | 预计 | 流入 | 流出 | 满编率 |
|---|---|---|---|---|---|---|
| 行业一部 | 167 | 164 | 168 | +5 | -4 | 102% |
| 财务一组 | 54 | 51 | 57 | +4 | -1 | 106% |
| 资本市场 | 5 | 5 | 5 | +0 | -0 | 100% |

### 待入职（7人，唯一L1：JICHAO SUN）

### 待离职（4人，全部IC：房心/六尾/波雅/诗源）

---

## 自动定时任务配置

### Cron 表达式
```
0 9 * * *  Asia/Shanghai
```
每天早上 9:00（上海时间）自动执行。

### 任务流程
1. 获取 SSO Cookie
2. 访问 `https://hr.xiaohongshu.com/ehr-workbench/hrbp`
3. 抓取部门列表、子部门数据、待入职/待离职人员
4. 基于模板生成 `hc_YYYYMMDD.html`（带日期戳）
5. 推送到 GitHub，**不覆盖** `hc_v3.html`
6. 在 hi 上 @用户 通知新链接

---

## 关键 API（需 SSO Cookie）

```bash
# 获取 SSO
/home/node/.openclaw/workspace/skills/data-fe-common-sso/script/run-sso.sh

BASE="https://hr.xiaohongshu.com/oasis/api/ehrworkbench"

# 部门 HC 汇总
GET $BASE/hrbp/pc/department/query

# 子部门明细（needChildren:true 为必传）
POST $BASE/hrbp/pc/department/subDepartments
body: {"departmentId":"5000273","needChildren":true}

# 待入职/待离职：通过浏览器 DOM 抓取 table
```

---

## 技术规范

| 项目 | 规范 |
|---|---|
| 文件格式 | 单文件自包含 HTML |
| 图表库 | ❌ 禁止引入 echarts/d3/chart.js |
| 图表实现 | ✅ 原生 SVG + CSS |
| JS 语法 | 必须通过 `node --check` 验证 |
| 字段规范 | `actual:0` 不能留空 |
| 发布方式 | GitHub Contents API (PUT) |

---

## 固定配置

| 项目 | 值 |
|---|---|
| 默认 GitHub Repo | `lushuting1/dashboard` |
| 专属看板 | `hc_v3.html` |
| 自动备份格式 | `hc_YYYYMMDD.html` |
| 行业一部 deptId | `5000273` |
| 财务一组 deptId | `5003008` |
| 资本市场 deptId | `5000785` |

---

## 使用示例

```bash
# 生成今日看板
OUTPUT=$(date +%Y%m%d)
cp hc_v3.html "hc_${OUTPUT}.html"

# 推送到 GitHub
CONTENT=$(base64 -w 0 "hc_${OUTPUT}.html")
curl -X PUT \
  -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/lushuting1/dashboard/contents/hc_${OUTPUT}.html" \
  -d "{\"message\":\"auto: daily update\",\"content\":\"$CONTENT\"}"
```
