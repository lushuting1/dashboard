---
name: hc-dashboard
description: 为小红书 HRBP 生成交互式 HC 管理看板，自动发布到 GitHub Pages。v1.1支持：气泡散点图、部门详情面板（子组柱状折线图+明细表）、流入流出人员明细（L1/L2高亮）、真实EHR数据接入。触发词：生成HC看板、更新HC看板、HC dashboard、HC流动情况、发我HC看板链接、看板里加流入流出明细。
---

# HC Dashboard Skill — v1.1

## 功能概览

生成交互式 HC 管理看板 HTML，发布到 GitHub Pages。

**当前地址**：https://lushuting1.github.io/dashboard/hc_v3.html

### v1.1 新增
- 🫧 气泡散点图（满编率 vs 在职规模）
- 🔍 部门详情面板（25子组 + 柱状折线组合图）
- 👤 流入流出明细（L1/L2 高亮真实姓名）
- ✅ 真实 EHR 数据（待入职 7 人 / 待离职 4 人）

### Tab 结构
- 📊 总览：3圆环图 + 气泡散点图 + 关键人流动
- 🛒 交易：KPI + 满编率排行 + 明细表 + 流入流出明细
- 🏢 商业：同结构
- 💰 财务：同结构

### 数据来源
- 行业一部 (deptId: 5000273)
- 财务一组 (deptId: 5003008)  
- 资本市场 (deptId: 5000785)

### 技术规范
- 纯 HTML + CSS + 原生 JS
- SVG 原生实现图表（无 echarts/d3）
- GitHub Contents API 发布
- SSO Cookie 访问 EHR 系统
