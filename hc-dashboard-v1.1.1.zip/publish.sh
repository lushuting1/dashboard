#!/bin/bash
# publish.sh - HC Dashboard 发布脚本
# 支持两种目标：GitHub Pages 或 Omni 内网平台
#
# 用法:
#   bash publish.sh <html_file> [target] [name]
#
#   target: github | omni (默认: omni)
#   name: 网页名称（Omni必填，如"HC看板-瑾瑜"）
#
# 示例:
#   bash publish.sh ./hc_20260402.html omni "HC看板-瑾瑜"
#   bash publish.sh ./hc_20260402.html github

set -euo pipefail

HTML_FILE="${1:-}"
TARGET="${2:-omni}"  # 默认使用 Omni
NAME="${3:-}"

if [[ -z "$HTML_FILE" || ! -f "$HTML_FILE" ]]; then
  echo "[ERROR] HTML 文件不存在: $HTML_FILE" >&2
  exit 1
fi

if [[ "$TARGET" == "omni" && -z "$NAME" ]]; then
  echo "[ERROR] Omni 发布需要提供网页名称，如: bash publish.sh file.html omni 'HC看板-瑾瑜'" >&2
  exit 1
fi

# ───────────────────────────────────────────
# Omni 发布
# ───────────────────────────────────────────
if [[ "$TARGET" == "omni" ]]; then
  echo "🚀 发布到 Omni 内网平台..."
  
  # 生成 path（小写，替换特殊字符为-）
  PATH_SLUG=$(echo "$NAME" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9\u4e00-\u9fa5]/-/g' | sed 's/^-//;s/-$//')
  PATH_SLUG="${PATH_SLUG:-site-$(date +%s)}"
  
  echo "   网页名称: $NAME"
  echo "   访问路径: $PATH_SLUG"
  
  # Step 1: 上传文件
  echo "   📤 上传文件..."
  
  # 创建临时 FormData 文件
  BOUNDARY="----FormBoundary$(date +%s)"
  TEMP_FILE=$(mktemp)
  
  # 构建 multipart/form-data
  {
    echo "--$BOUNDARY"
    echo 'Content-Disposition: form-data; name="path"'
    echo ''
    echo "$PATH_SLUG"
    echo "--$BOUNDARY"
    echo 'Content-Disposition: form-data; name="file_count"'
    echo ''
    echo '1'
    echo "--$BOUNDARY"
    echo 'Content-Disposition: form-data; name="file_0"; filename="index.html"'
    echo 'Content-Type: text/html'
    echo ''
    cat "$HTML_FILE"
    echo "--$BOUNDARY"
    echo 'Content-Disposition: form-data; name="relative_path_0"'
    echo ''
    echo 'index.html'
    echo "--$BOUNDARY--"
  } > "$TEMP_FILE"
  
  UPLOAD_RESP=$(curl -s -X POST "https://omni.sit.xiaohongshu.com/api/v1/config/upload" \
    -H "Content-Type: multipart/form-data; boundary=$BOUNDARY" \
    --data-binary "@$TEMP_FILE" 2>&1)
  
  rm -f "$TEMP_FILE"
  
  if ! echo "$UPLOAD_RESP" | grep -q '"success":true\|"path"'; then
    echo "[ERROR] 上传失败: $UPLOAD_RESP" >&2
    exit 1
  fi
  
  # Step 2: 创建站点记录
  echo "   📝 创建站点..."
  CREATE_RESP=$(curl -s -X POST "https://omni.sit.xiaohongshu.com/api/v1/config/websites" \
    -H "Content-Type: application/json" \
    -d "{\"name\":\"$NAME\",\"path\":\"$PATH_SLUG\"}")
  
  echo ""
  echo "✅ 发布成功！"
  echo ""
  echo "🔗 访问链接:"
  echo "   https://omni.sit.xiaohongshu.com/$PATH_SLUG/"
  echo ""
  echo "📱 分享给同事:"
  echo "   打开 https://omni.sit.xiaohongshu.com/$PATH_SLUG/ 即可查看 HC 看板"
  
  exit 0
fi

# ───────────────────────────────────────────
# GitHub Pages 发布（原有逻辑）
# ───────────────────────────────────────────
if [[ "$TARGET" == "github" ]]; then
  echo "🚀 发布到 GitHub Pages..."
  
  # Token 读取
  TOKEN="${GITHUB_TOKEN:-}"
  if [[ -z "$TOKEN" ]]; then
    TOKEN_FILE="${HOME}/.openclaw/workspace/.github_token"
    [[ -f "$TOKEN_FILE" ]] && TOKEN=$(cat "$TOKEN_FILE" | tr -d '[:space:]')
  fi
  [[ -z "$TOKEN" ]] && TOKEN="ghp_your_default_token"
  
  REPO="${GITHUB_PAGES_REPO:-lushuting1/dashboard}"
  BASENAME=$(basename "$HTML_FILE")
  
  # 获取 SHA
  EXISTING_SHA=$(curl -s \
    -H "Authorization: token $TOKEN" \
    "https://api.github.com/repos/$REPO/contents/$BASENAME" \
    | python3 -c "import json,sys; print(json.load(sys.stdin).get('sha',''))" 2>/dev/null || echo "")
  
  # Base64 编码
  CONTENT_B64=$(base64 -w 0 < "$HTML_FILE")
  
  # 构建 payload
  if [[ -n "$EXISTING_SHA" ]]; then
    PAYLOAD=$(python3 -c "
import json
print(json.dumps({
  'message': 'Update $BASENAME',
  'content': '$CONTENT_B64',
  'sha': '$EXISTING_SHA'
}))")
  else
    PAYLOAD=$(python3 -c "
import json
print(json.dumps({
  'message': 'Create $BASENAME',
  'content': '$CONTENT_B64'
}))")
  fi
  
  # 推送
  RESPONSE=$(curl -s -X PUT \
    -H "Authorization: token $TOKEN" \
    -H "Content-Type: application/json" \
    "https://api.github.com/repos/$REPO/contents/$BASENAME" \
    -d "$PAYLOAD")
  
  # 解析结果
  URL=$(echo "$RESPONSE" | python3 -c "
import json, sys
d = json.load(sys.stdin)
if 'content' in d:
    owner, reponame = '$REPO'.split('/')
    path = '$BASENAME'
    print(f'https://{owner}.github.io/{reponame}/{path}')
else:
    print('')
" 2>/dev/null || echo "")
  
  if [[ -n "$URL" ]]; then
    echo "✅ 发布成功: $URL"
    exit 0
  else
    echo "[ERROR] 发布失败: $(echo "$RESPONSE" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("message","Unknown error"))')" >&2
    exit 1
  fi
fi

echo "[ERROR] 未知目标: $TARGET (应为 omni 或 github)" >&2
exit 1
