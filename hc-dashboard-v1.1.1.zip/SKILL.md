---
name: hc-dashboard
description: 为小红书 HRBP 生成交互式 HC 管理看板。支持 Omni 内网部署（推荐）和 GitHub Pages。自动抓取 EHR 数据，生成可视化看板，包含气泡散点图、部门详情面板、流入流出人员明细（L1/L2高亮）。触发词：生成HC看板、更新HC看板、HC dashboard。
---

# HC Dashboard Skill — v1.1

## 🚀 快速开始（Omni 部署 - 推荐）

```bash
# 1. 运行 skill 生成看板
openclaw skill run hc-dashboard

# 2. 选择 Omni 部署，输入名称如 "HC看板-瑾瑜"
# 3. 获得内网链接：https://omni.sit.xiaohongshu.com/<name>/
```

**无需 GitHub Token，每位 HR 直接发布到自己的 Omni 链接。**

---

## 📋 功能特性

| 特性 | 说明 |
|---|---|
| 🫧 气泡散点图 | X=满编率 / Y=在职规模 / 气泡大小=budget，SVG原生实现 |
| 🔍 部门详情面板 | 点击行业一部 → 弹出25子组完整数据 |
| 📊 子组组合图 | 双柱(在职/目标)+折线(满编率)，纯SVG |
| 👤 流入流出明细 | L1/L2 真实姓名高亮显示 |
| ✅ 真实EHR数据 | 待入职7人/待离职4人，系统实时数据 |
| ⏰ 定时自动更新 | 每天9点自动生成日期戳文件 |

---

## 🌐 部署方式对比

| 方式 | 是否需要Token | 访问链接 | 适合场景 |
|---|---|---|---|
| **Omni**（推荐） | ❌ 不需要 | `https://omni.sit.xiaohongshu.com/<name>/` | **所有小红书员工**，内网访问 |
| GitHub Pages | ✅ 需要 GitHub Token | `https://xxx.github.io/xxx.html` | 外部展示 |

**Omni 优势**：
- 无需 GitHub 账号
- 无需配置 Token
- 小红书 SSO 自动登录
- 内网访问速度快
- 支持更新已发布页面

---

## 🔧 使用详情

### Omni 部署流程

```bash
# 生成看板（交互式）
openclaw skill run hc-dashboard

# 或指定参数
openclaw skill run hc-dashboard --name "HC看板-瑾瑜" --target omni
```

输出示例：
```
✅ 发布成功！

🔗 访问链接:
   https://omni.sit.xiaohongshu.com/hc-kan-ban-jin-yu/

📱 分享给同事:
   打开 https://omni.sit.xiaohongshu.com/hc-kan-ban-jin-yu/
```

### GitHub Pages 部署（备选）

如需部署到 GitHub Pages，需配置 Token：

```bash
# 创建 token 文件
echo "ghp_your_token" > ~/.openclaw/workspace/.github_token
chmod 600 ~/.openclaw/workspace/.github_token

# 运行 skill
openclaw skill run hc-dashboard --target github
```

---

## 📁 文件命名规则

| 场景 | 文件名/路径 | 说明 |
|---|---|---|
| 专属看板 | `hc_v3.html` | 瑾瑜专属，永不覆盖 |
| 自动每日备份 | `hc_YYYYMMDD.html` | 系统自动生成 |
| Omni 发布 | `https://omni.sit.xiaohongshu.com/<name>/` | 每人独立 |
| GitHub 发布 | `hc_<name>.html` | 可选部署 |

---

## 🔌 数据来源

- **工作台**: https://hr.xiaohongshu.com/ehr-workbench/hrbp
- **部门数据**: /oasis/api/ehrworkbench/hrbp/pc/department/query
- **子部门**: /oaxis/api/ehrworkbench/hrbp/pc/department/subDepartments
- **待入职/离职**: 浏览器抓取 DOM table

---

## ⚙️ 技术规范

| 项目 | 说明 |
|---|---|
| 前端 | 纯 HTML + CSS + 原生 JS |
| 图表 | SVG 原生（无 echarts/d3/chart.js）|
| 部署 | Omni REST API 或 GitHub Contents API |
| 认证 | 小红书 SSO（Omni）或 GitHub Token |

---

## 📝 命令行用法

```bash
# 发布到 Omni（推荐）
bash publish.sh ./hc_20260402.html omni "HC看板-瑾瑜"

# 发布到 GitHub Pages
bash publish.sh ./hc_20260402.html github

# 带自定义名称的 GitHub 发布
bash publish.sh ./hc_20260402.html github "hc-jinyu"
```
